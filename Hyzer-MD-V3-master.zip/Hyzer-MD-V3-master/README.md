<div align="center">
<img src="https://telegra.ph/file/fadf93e02010bf5a891e6.jpg" alt="Hyzer Md-V3" width="300" />

</p>
<h1 align="center">RulzTod.Ofc</h1>

>
>
>
</div>
<p align="center">
  <a href="https://github.com/Warikrr"><img title="GitHub" src="https://img.shields.io/badge/Github-Hyzerr.svg?style=for-the-badge&logo=github" /></a>
  <a href="httts://instagram.com/sahrulwara_____"><img title="Instagram " src="https://img.shields.io/badge/Instagram-Hyzerr.svg?style=for-the-badge&logo=instagram" /></a>
  <a href="https://youtu.be/jOhhY7ef_qM"><img title="Youtube" src="https://img.shields.io/badge/Youtube-Hyzerr.svg?style=for-the-badge&logo=youtube" /></a>
  <a href="https://api-hyzerr.herokuapp.com"><img title="Rest Api" src="https://img.shields.io/badge/Rest Api-Hyzerr.svg?style=for-the-badge&logo=twitter" /></a>
  <h4 align="center">
  <a
  <a href="https://wa.me/6285822347348">Chat Saya Jika Ingin Menanyakan Sesuatu </a>
</h4>
</p>

# Ambil Session Disini

> Buka [ Linknya Disini ](https://replit.com/@zeeoneofc/Session-Md?lita=1&outputonly=1#.replit) 
> Untuk Tutorialnya Liat Dan Subscribe [ Here ](https://youtu.be/jOhhY7ef_qM) 

### Preview bot
------------------
- [x] Welcome <details><summary>Screenshot</summary><img src="https://telegra.ph/file/38cde079ebb9a4bf393e5.jpg"></details>
- [x] Reply bot <details><summary>Screenshot</summary><img src="https://telegra.ph/file/98c48528bd962f279ea7e.jpg"></details>
- [x] Menu  <details><summary>Screenshot</summary><img src="https://telegra.ph/file/d430618ba6ec416d33cf7.jpg"></details>
------------------

# Run On Heroku

WhatsApp Bot Multi Device

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Warikrr/Hyzer-MD-V3)


# Heroku Buildpack

| BuildPack | LINK |
|--------|--------|
| **FFMPEG** |[HERE](https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest) |
| **IMAGEMAGICK** | [HERE](https://github.com/mcollina/heroku-buildpack-imagemagick.git) |
| **Node.js**     | heroku/nodejs|

# Creator Bot
 [![Ilman](https://github.com/ilmanhdyt.png?size=200)](https://github.com/ilmanhdyt) | [![Hyzer](https://github.com/Hyzerr.png?size=200)](https://github.com/Hyzerr) 
----|----
[Ilman](https://github.com/ilmanhdyt) | [Hyzer](https://github.com/Hyzerr) 
 Author | Creator
 
### ArullOfc Statistics

[![Hyzer GitHub Stats](https://github-readme-stats.vercel.app/api?username=Hyzerr&show_icons=true&hide=issues&theme=radical)](https://github-readme-stats.vercel.app)
[![Hyzer Top Languages](https://github-readme-stats.vercel.app/api/top-langs?username=Hyzerr&layout=compact&theme=radical)](https://github-readme-stats.vercel.app)

# Thanks to
 [![Nurutomo](https://github.com/Nurutomo.png?size=200)](https://github.com/Nurutomo) | [![Ariffb](https://github.com/ariffb25.png?size=200)](https://github.com/ariffb25) | [![F](https://github.com/Paquito1923.png?size=200)](https://github.com/Paquito1923)
----|----|----
[Nurutomo](https://github.com/Nurutomo) | [Ariffb](https://github.com/ariffb25) | [Elyas](https://github.com/Paquito1923)
 Helpfully | Suhu? | Friends

---------

## Request Fitur To
[`Creator Here`](https://wa.me/621330251835?text=Banh+req+fitur) 
